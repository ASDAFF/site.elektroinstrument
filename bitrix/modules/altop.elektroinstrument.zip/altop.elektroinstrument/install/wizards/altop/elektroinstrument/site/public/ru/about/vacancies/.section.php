<?
$sSectionName = "Вакансии";
$arDirProperties = array();
?>