<?
$sSectionName = "Новости";
$arDirProperties = Array();
?>