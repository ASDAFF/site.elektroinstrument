<?
$MESS["WIZ_DISCOUNT"] = "Скидка";
?>