<?
$MESS ['CATALOG_COMPARE_ELEMENTS'] = "Сравнение";
?>