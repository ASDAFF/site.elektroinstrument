<?
$sSectionName = "Награды и достижения";
$arDirProperties = Array();
?>