<?
$MESS ['PROFILE_DATA_SAVED'] = "Изменения сохранены";
$MESS ['NAME'] = "Имя";
$MESS ['LAST_NAME'] = "Фамилия";
$MESS ['SECOND_NAME'] = "Отчество";
$MESS ['PERSONAL_PHOTO'] = "Изображение профиля";
$MESS ['NEW_PASSWORD_CONFIRM'] = "Подтверждение пароля";
$MESS ['NEW_PASSWORD_REQ'] = "Новый пароль";
$MESS ['MAIN_SAVE'] = "Сохранить";
$MESS ['MAIN_PSWD'] = "Пароль";
$MESS ['LEGEND_PROFILE'] = "Личные данные";
?>