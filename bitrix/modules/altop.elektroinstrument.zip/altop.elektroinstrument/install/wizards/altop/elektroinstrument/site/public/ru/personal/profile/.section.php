<?
$sSectionName = "Мой профиль";
$arDirProperties = array();
?>