<?
$MESS['SECT_TITLE'] = 'Страница';
?>
