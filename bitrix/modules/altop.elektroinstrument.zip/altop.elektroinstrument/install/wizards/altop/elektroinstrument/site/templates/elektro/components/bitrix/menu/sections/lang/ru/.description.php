<?
$MESS ['MENU_SECT_NAME'] = "Меню из разделов инфоблока";
$MESS ['MENU_SECT_DESC'] = "Меню из разделов инфоблока";
?>