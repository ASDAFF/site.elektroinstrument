<?
$LOCATION_FILE_MAP = array(
	'loc_ussr.csv' => 'customs_union.csv',
);