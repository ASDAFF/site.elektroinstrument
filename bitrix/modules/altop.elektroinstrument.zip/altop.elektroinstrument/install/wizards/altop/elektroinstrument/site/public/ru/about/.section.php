<?
$sSectionName = "О Компании";
$arDirProperties = Array();
?>