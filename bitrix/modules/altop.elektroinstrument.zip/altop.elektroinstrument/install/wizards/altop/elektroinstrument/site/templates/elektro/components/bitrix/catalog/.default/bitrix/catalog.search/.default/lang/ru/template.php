<?
$MESS["COUNT_ITEMS"] = "Товаров:";
$MESS["SECT_SORT_LABEL_FULL"] = "Сортировать по";
$MESS["SECT_SORT_LABEL_SHORT"] = "По";
$MESS["SECT_SORT_default"] = "умолчанию";
$MESS["SECT_SORT_price"] = "цене";
$MESS["SECT_SORT_rating"] = "рейтингу";
$MESS["SECT_COUNT_LABEL_FULL"] = "Показывать по";
$MESS["SECT_COUNT_LABEL_SHORT"] = "По";
$MESS["SECT_COUNT_ALL"] = "Все";
$MESS["SECT_VIEW_list"] = "Список";
$MESS["SECT_VIEW_table"] = "Плитка";
$MESS["SECT_VIEW_price"] = "Прайс";
$MESS["CMP_TITLE"] = "Поиск";
$MESS["SECT_TITLE"] = "Страница";
$MESS["CT_BCSE_NOT_FOUND"] = "Сожалеем, но ничего не найдено.";
?>