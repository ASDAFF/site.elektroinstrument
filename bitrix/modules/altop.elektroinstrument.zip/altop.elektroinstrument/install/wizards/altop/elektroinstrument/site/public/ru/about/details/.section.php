<?
$sSectionName = "Реквизиты";
$arDirProperties = Array();
?>