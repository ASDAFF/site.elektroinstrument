<?
$sSectionName = "Контакты";
$arDirProperties = array();
?>