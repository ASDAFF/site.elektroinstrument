<?$aMenuLinks = Array(
	Array(
		"История компании", 
		"history/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Сертификаты и лицензии", 
		"certificates/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Награды и достижения", 
		"awards/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Наши партнеры", 
		"partners/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Отзывы о компании", 
		"responses/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Наши сотрудники", 
		"employees/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вакансии", 
		"vacancies/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Реквизиты", 
		"details/", 
		Array(), 
		Array(), 
		"" 
	)
);?>