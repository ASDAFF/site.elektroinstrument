<?
$sSectionName = "История компании";
$arDirProperties = Array();
?>