<?
$MESS ['MFT_NAME'] = "Имя";
$MESS ['MFT_EMAIL'] = "Email";
$MESS ['MFT_MESSAGE'] = "Сообщение";
$MESS ['MFT_CAPTCHA'] = "Код с картинки";
$MESS ['MFT_SUBMIT'] = "Отправить";
?>