<?
$MESS["CMP_COMPARE"] = "Сравнение товаров";
$MESS["CMP_TITLE"] = "Таблица сравнения";
?>