<?$aMenuLinks = Array(
	Array(
		"Каталог продукции", 
		"#SITE_DIR#catalog/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Электроинструменты", 
		"#SITE_DIR#catalog/elektroinstrumenty/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Садовая техника", 
		"#SITE_DIR#catalog/sadovaya_tekhnika/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Климатическая техника", 
		"#SITE_DIR#catalog/klimaticheskaya_tekhnika/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Ручной инструмент", 
		"#SITE_DIR#catalog/ruchnoy_instrument/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Строительная техника", 
		"#SITE_DIR#catalog/stroitelnaya_tekhnika/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Строительные материалы", 
		"#SITE_DIR#catalog/stroitelnye_materialy/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Электротехника", 
		"#SITE_DIR#catalog/elektrotekhnika/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Станки", 
		"#SITE_DIR#catalog/stanki/", 
		Array(), 
		Array(), 
		"" 
	)
);?>