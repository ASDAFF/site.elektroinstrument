<?
$sSectionName = "Наши сотрудники";
$arDirProperties = Array();
?>