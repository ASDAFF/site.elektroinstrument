<?
$MESS["SERVICE_MAIN_SETTINGS"] = "Настройка сайта";
$MESS["SERVICE_IBLOCK_DEMO_DATA"] = "Создание инфоблоков и импорт демо данных";
$MESS["SERVICE_SALE_DEMO_DATA"] = "Настройка интернет-магазина";
$MESS["SERVICE_CATALOG_SETTINGS"] = "Настройка торгового каталога";
?>