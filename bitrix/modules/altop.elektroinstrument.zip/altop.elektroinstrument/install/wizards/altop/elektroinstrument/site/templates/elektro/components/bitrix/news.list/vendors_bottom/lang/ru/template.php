<?
$MESS["VENDORS_TITLE"] = "Производители";
$MESS["ALL_VENDORS"] = "Все производители";
?>