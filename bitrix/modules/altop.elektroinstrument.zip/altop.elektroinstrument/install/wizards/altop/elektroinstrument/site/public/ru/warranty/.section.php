<?
$sSectionName = "Гарантия";
$arDirProperties = Array();
?>