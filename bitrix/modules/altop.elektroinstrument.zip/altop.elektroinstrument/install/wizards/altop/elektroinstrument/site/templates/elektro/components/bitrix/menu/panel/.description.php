<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("MENU_VERT_MULTI_NAME"),
	"DESCRIPTION" => GetMessage("MENU_VERT_MULTI_DESC"),
);?>