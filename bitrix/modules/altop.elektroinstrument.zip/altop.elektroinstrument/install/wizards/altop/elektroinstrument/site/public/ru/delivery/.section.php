<?
$sSectionName = "Доставка";
$arDirProperties = array();
?>