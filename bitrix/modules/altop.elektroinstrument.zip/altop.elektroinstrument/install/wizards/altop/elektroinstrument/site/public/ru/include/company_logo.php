<a href="<?=SITE_DIR?>">
	<img src="<?=SITE_TEMPLATE_PATH?>/images/logo.png" alt="logo" />
	<span>Готовый интернет-магазин на 1С-Битрикс</span>
</a>