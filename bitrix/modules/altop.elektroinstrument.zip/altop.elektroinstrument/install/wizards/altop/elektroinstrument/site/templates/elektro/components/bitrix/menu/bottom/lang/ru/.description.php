<?
$MESS ['MENU_BOTTOM_NAME'] = "Нижнее меню";
$MESS ['MENU_BOTTOM_DESC'] = "Нижнее меню";
?>