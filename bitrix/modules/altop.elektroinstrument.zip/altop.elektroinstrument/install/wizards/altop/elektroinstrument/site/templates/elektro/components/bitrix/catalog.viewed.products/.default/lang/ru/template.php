<?
$MESS ['CATALOG_ALREADY_SEEN'] = "Вы смотрели";
?>