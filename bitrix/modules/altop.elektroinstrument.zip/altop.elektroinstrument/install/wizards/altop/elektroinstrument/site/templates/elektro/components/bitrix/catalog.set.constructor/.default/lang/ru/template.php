<?
$MESS["CATALOG_SET_BUY_SET"] = "Купить набор";
$MESS["CATALOG_SET_DISCOUNT_DIFF"] = "Экономия";
$MESS["CATALOG_SET_ADD_TO_CART"] = "В корзину";
$MESS["CATALOG_SET_ADDED"] = "Добавлено";
$MESS["CATALOG_SET_CONSTRUCT"] = "Собрать свой набор";
$MESS["CATALOG_SET_POPUP_TITLE_BAR"] = "Соберите свой собственный набор";
$MESS["CATALOG_SET_POPUP_DESC"] = "Вы можете добавить в набор до 3-х дополнительных аксессуаров";
$MESS["CATALOG_SET_ADDED2BASKET"] = "Набор добавлен в корзину";
?>