<?
$MESS["S_PHONE"] = ", тел: ";
$MESS["S_SCHEDULE"] = ", график: ";
$MESS["S_BALANCE"] = "Общий остаток на складах";
?>