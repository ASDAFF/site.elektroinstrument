<?
$sSectionName = "Отзывы о компании";
$arDirProperties = Array();
?>