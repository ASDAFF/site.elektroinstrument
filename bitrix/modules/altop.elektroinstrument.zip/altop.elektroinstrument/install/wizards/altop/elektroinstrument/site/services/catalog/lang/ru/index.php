<?
$MESS["STORE_NAME_1"] = "Магазин 1";
$MESS["STORE_ADR_1"] = "г. Москва, ул. Фадеева 2";
$MESS["STORE_GPS_N_1"] = "55.77301";
$MESS["STORE_GPS_S_1"] = "37.602301";
$MESS["STORE_SCHEDULE_1"] = "ПН-ПТ 9:00 - 22:00";
$MESS["STORE_NAME_2"] = "Магазин 2";
$MESS["STORE_ADR_2"] = "Москва, 4 Добрыненский переулок 6";
$MESS["STORE_GPS_N_2"] = "55.727475";
$MESS["STORE_GPS_S_2"] = "37.617752";
$MESS["STORE_SCHEDULE_2"] = "ПН-СБ 9:00 - 23:00";
?>