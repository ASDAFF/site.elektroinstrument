<?$aMenuLinks = Array(
	Array(
		"Контакты", 
		"#SITE_DIR#contacts/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Карта сайта", 
		"#SITE_DIR#map/", 
		Array(), 
		Array(), 
		"" 
	)
);?>