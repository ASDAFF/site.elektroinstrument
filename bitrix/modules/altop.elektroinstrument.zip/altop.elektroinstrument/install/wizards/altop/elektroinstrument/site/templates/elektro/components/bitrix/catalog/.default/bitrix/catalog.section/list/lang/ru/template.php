<?
$MESS["CATALOG_ELEMENT_NEWPRODUCT"] = "New";
$MESS["CATALOG_ELEMENT_SALELEADER"] = "Хит";
$MESS["CATALOG_ELEMENT_ARTNUMBER"] = "Артикул: ";
$MESS["CATALOG_ELEMENT_NO_PRICE"] = "Не указана цена";
$MESS["CATALOG_ELEMENT_SKIDKA"] = "Экономия";
$MESS["CATALOG_ELEMENT_UNIT"] = "за";
$MESS["CATALOG_ELEMENT_AVAILABLE"] = "В наличии";
$MESS["CATALOG_ELEMENT_NOT_AVAILABLE"] = "Нет в наличии";
$MESS["CATALOG_ELEMENT_ADD_TO_COMPARE"] = "Добавить к сравнению";
$MESS["CATALOG_ELEMENT_ADD_TO_DELAY"] = "Отложить";
$MESS["CATALOG_ELEMENT_ADD_TO_CART"] = "В корзину";
$MESS["CATALOG_ELEMENT_ADDED"] = "Добавлено";
$MESS["CATALOG_ELEMENT_ASK_PRICE_FULL"] = "Запросить цену";
$MESS["CATALOG_ELEMENT_ASK_PRICE_SHORT"] = "Запрос цены";
$MESS["CATALOG_ELEMENT_UNDER_ORDER"] = "Под заказ";
$MESS["CATALOG_ELEMENT_MORE_OPTIONS"] = "Выберите дополнительные параметры товара";
$MESS["CATALOG_EMPTY_RESULT"] = "По вашему запросу ничего не найдено.";
?>