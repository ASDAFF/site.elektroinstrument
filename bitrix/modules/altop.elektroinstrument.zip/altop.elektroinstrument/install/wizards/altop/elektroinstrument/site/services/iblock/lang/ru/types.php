<?
$MESS ["CATALOG_TYPE_NAME"] = "Каталог";
$MESS ["CATALOG_SECTION_NAME"] = "Разделы";
$MESS ["CATALOG_ELEMENT_NAME"] = "Элементы";

$MESS ["CONTENT_TYPE_NAME"] = "Контент";
$MESS ["CONTENT_SECTION_NAME"] = "Разделы";
$MESS ["CONTENT_ELEMENT_NAME"] = "Элементы";

?>