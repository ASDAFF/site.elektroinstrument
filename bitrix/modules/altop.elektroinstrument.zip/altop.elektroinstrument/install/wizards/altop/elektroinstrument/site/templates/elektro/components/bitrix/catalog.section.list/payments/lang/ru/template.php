<?
$MESS['PAYMENT_ITEM_URL'] = "Инструкция по оплате";
?>