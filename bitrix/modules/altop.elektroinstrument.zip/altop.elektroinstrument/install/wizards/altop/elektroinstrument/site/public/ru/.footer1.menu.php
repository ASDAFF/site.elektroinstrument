<?$aMenuLinks = Array(
	Array(
		"Как купить", 
		"#SITE_DIR#howtobuy/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Способы оплаты", 
		"#SITE_DIR#payments/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Способы доставки", 
		"#SITE_DIR#delivery/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Гарантия", 
		"#SITE_DIR#warranty/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Возврат и обмен", 
		"#SITE_DIR#returns/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вопросы и ответы", 
		"#SITE_DIR#faq/", 
		Array(), 
		Array(), 
		"" 
	)
);?>