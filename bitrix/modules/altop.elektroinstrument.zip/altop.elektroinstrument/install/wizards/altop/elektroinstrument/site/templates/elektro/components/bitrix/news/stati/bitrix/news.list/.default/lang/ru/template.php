<?
$MESS ['NEWS_ELEMENT_DELETE_CONFIRM'] = 'Вы уверены, что хотите удалить новость?';
$MESS ['NEWS_MORE'] = 'Подробнее...';
?>