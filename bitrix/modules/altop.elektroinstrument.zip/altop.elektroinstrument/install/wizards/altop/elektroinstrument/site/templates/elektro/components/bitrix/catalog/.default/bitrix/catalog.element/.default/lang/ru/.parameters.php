<?
$MESS["F_MESSAGES_PER_PAGE"] = "Количество сообщений на одной странице";
$MESS["F_FORUM_ID"] = "ID форума для отзывов";
$MESS["F_USE_CAPTCHA"] = "Использовать CAPTCHA";
$MESS["F_SHOW_MINIMIZED"] = "Сворачивать форму добавления отзыва";
$MESS["SHOW_RATING"] = "Включить рейтинг";
$MESS["SHOW_RATING_CONFIG"] = "по умолчанию";
$MESS["RATING_TYPE"] = "Вид кнопок рейтинга";
$MESS["RATING_TYPE_CONFIG"] = "по умолчанию";
$MESS["RATING_TYPE_STANDART_TEXT"] = "Нравится / Не нравится (текстовый)";
$MESS["RATING_TYPE_STANDART_GRAPHIC"] = "Нравится / Не нравится (графический)";
$MESS["RATING_TYPE_LIKE_TEXT"] = "Мне нравится (текстовый)";
$MESS["RATING_TYPE_LIKE_GRAPHIC"] = "Мне нравится (графический)";
$MESS["T_IBLOCK_DESC_USE_REVIEW"] = "Разрешить отзывы";
?>