<?
$MESS["NEWS_TITLE"] = "Новости";
?>