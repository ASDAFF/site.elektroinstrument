<?
$MESS["SECT_SORT_LABEL_FULL"] = "Сортировать по";
$MESS["SECT_SORT_LABEL_SHORT"] = "По";
$MESS["SECT_SORT_default"] = "Умолчанию";
$MESS["SECT_SORT_price"] = "Цене";
$MESS["SECT_SORT_rating"] = "Рейтингу";
$MESS["SECT_COUNT_LABEL_FULL"] = "Показывать по";
$MESS["SECT_COUNT_LABEL_SHORT"] = "По";
$MESS["SECT_COUNT_ALL"] = "Все";
$MESS["SECT_VIEW_list"] = "Список";
$MESS["SECT_VIEW_table"] = "Плитка";
$MESS["SECT_VIEW_price"] = "Прайс";
$MESS["SECT_TITLE"] = "Страница";
?>