<?
$sSectionName = "Обзоры и советы";
$arDirProperties = Array();
?>