<?
$sSectionName = "Email рассылки";
$arDirProperties = array();
?>