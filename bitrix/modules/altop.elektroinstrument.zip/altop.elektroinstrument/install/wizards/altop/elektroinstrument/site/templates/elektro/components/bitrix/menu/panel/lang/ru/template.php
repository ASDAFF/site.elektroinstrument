<?
$MESS ['MENU'] = "Меню";
$MESS ['MENU_HOME'] = "Главная";
$MESS ['MENU_ITEM_ACCESS_DENIED'] = "Доступ запрещен";
?>