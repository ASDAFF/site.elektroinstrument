<?
$MESS["ALL_VENDORS"] = "Все производители";
?>