<?
$MESS["CMP_TITLE"] = "Поиск";
?>