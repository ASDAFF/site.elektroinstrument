<?
	$sSectionName = "Личный кабинет";
	$arDirProperties = array(
		"PERSONAL_SECTION" => "1",
	)
?>