<?
$sSectionName = "Вопросы и ответы";
$arDirProperties = Array();
?>