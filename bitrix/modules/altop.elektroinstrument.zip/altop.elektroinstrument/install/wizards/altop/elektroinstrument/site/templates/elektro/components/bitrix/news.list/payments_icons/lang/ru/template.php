<?
$MESS["PAYMENT_METHODS"] = "Способы оплаты";
?>