<?
$sSectionName = "Сертификаты и лицензии";
$arDirProperties = Array();
?>