<?
$MESS ['TP_CBIV_DISPLAY_AS_RATING'] = "В качестве рейтинга показывать";
$MESS ['TP_CBIV_AVERAGE'] = "Среднее значение";
$MESS ['TP_CBIV_RATING'] = "Рейтинг";
?>