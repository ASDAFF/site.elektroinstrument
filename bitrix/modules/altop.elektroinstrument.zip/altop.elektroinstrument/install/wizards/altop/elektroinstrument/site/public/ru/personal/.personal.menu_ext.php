<?$aMenuLinks = Array(
	Array(
		"Мой профиль", 
		"#SITE_DIR#personal/profile/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Моя корзина", 
		"#SITE_DIR#personal/cart/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Мои заказы", 
		"#SITE_DIR#personal/order/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Email рассылки", 
		"#SITE_DIR#personal/subscribe/", 
		Array(), 
		Array(), 
		"" 
	)
);?>