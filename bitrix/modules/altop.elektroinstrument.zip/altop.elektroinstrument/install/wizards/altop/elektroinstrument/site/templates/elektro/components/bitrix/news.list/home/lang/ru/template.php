<?
$MESS["NEWS_TITLE"] = "Новости";
$MESS["ALL_NEWS"] = "Все новости";
?>