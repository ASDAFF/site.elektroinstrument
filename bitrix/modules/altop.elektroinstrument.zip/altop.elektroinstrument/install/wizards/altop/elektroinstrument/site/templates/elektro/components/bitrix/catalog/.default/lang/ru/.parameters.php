<?
$MESS['T_IBLOCK_TYPE_REVIEWS'] = "Тип инфоблока отзывов к товарам";
$MESS['T_IBLOCK_ID_REVIEWS'] = "ID инфоблока отзывов к товарам";
$MESS['T_IBLOCK_DESC_IMG_WIDTH'] = "Ширина картинки для анонса";
$MESS['T_IBLOCK_DESC_IMG_HEIGHT'] = "Высота картинки для анонса";
$MESS['T_IBLOCK_DESC_DETAIL_IMG_WIDTH'] = "Ширина картинки для детального просмотра";
$MESS['T_IBLOCK_DESC_DETAIL_IMG_HEIGHT'] = "Высота картинки для детального просмотра";
$MESS['T_IBLOCK_DESC_MORE_PHOTO_WIDTH'] = "Ширина картинки для анонса дополнительных изображений";
$MESS['T_IBLOCK_DESC_MORE_PHOTO_HEIGHT'] = "Высота картинки для анонса дополнительных изображений";
$MESS["PATH_TO_SHIPPING"] = "Путь к информации о доставке";
$MESS["T_IBLOCK_DESC_SHARPEN"] = "Резкость при масштабировании картинок (от 1 до 100)";
$MESS["T_IBLOCK_PROPERTY_MOD"] = "Свойства для выбора (значения которых сможет выбрать покупатель)";
$MESS["CP_BC_TPL_USE_BIG_DATA"] = "Показывать персональные рекомендации";
$MESS["CP_BC_TPL_BIG_DATA_RCM_TYPE"] = "Тип рекомендации";
$MESS["CP_BC_TPL_RCM_BESTSELLERS"] = "Самые продаваемые";
$MESS["CP_BC_TPL_RCM_PERSONAL"] = "Персональные рекомендации";
$MESS["CP_BC_TPL_RCM_SOLD_WITH"] = "Продаваемые с этим товаром";
$MESS["CP_BC_TPL_RCM_VIEWED_WITH"] = "Просматриваемые с этим товаром";
$MESS["CP_BC_TPL_RCM_SIMILAR"] = "Похожие товары";
$MESS["CP_BC_TPL_RCM_SIMILAR_ANY"] = "Продаваемые/Просматриваемые/Похожие товары";
$MESS["CP_BC_TPL_RCM_PERSONAL_WBEST"] = "Самые продаваемые/Персональные";
$MESS["CP_BC_TPL_RCM_RAND"] = "Любая рекомендация";
?>