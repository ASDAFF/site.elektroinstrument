<?
$sSectionName = "Наши партнеры";
$arDirProperties = array();
?>