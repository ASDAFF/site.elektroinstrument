<?
$MESS ['FILTER_DISPLAY_HIDDEN'] = "Подобрать товары по параметрам";
$MESS ['FILTER_HIDDEN'] = "Скрыть подбор";
$MESS ['PRICE_FROM'] = "от";
$MESS ['PRICE_TO'] = "до";
$MESS ['PRODUCT_TYPE'] = "Тип товара";
$MESS ['CT_BCSF_FILTER_ALL'] = "Все";
$MESS ['CT_BCSF_FILTER_COUNT'] = "Найдено товаров: #ELEMENT_COUNT#";
$MESS ['FILTER_RESET'] = "Сбросить";
$MESS ['FILTER_SET'] = "Показать";
$MESS ['COUNT_ITEMS'] = "Товаров:";
?>