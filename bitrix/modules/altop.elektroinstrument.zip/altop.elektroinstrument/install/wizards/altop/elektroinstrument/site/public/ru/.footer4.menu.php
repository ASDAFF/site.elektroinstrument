<?$aMenuLinks = Array(
	Array(
		"О Компании", 
		"#SITE_DIR#about/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"История компании", 
		"#SITE_DIR#about/history/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Сертификаты", 
		"#SITE_DIR#about/certificates/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Награды и достижения", 
		"#SITE_DIR#about/awards/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Наши партнеры", 
		"#SITE_DIR#about/partners/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Отзывы о компании", 
		"#SITE_DIR#about/responses/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Наши сотрудники", 
		"#SITE_DIR#about/employees/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вакансии", 
		"#SITE_DIR#about/vacancies/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Реквизиты", 
		"#SITE_DIR#about/details/", 
		Array(), 
		Array(), 
		"" 
	)
);?>