<?
$sSectionName = "Способы оплаты";
$arDirProperties = array();
?>