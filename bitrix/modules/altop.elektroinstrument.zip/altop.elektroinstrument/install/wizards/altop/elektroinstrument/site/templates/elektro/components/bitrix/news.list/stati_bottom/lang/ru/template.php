<?
$MESS["STATI_TITLE"] = "Обзоры и советы";
$MESS["ALL_STATI"] = "Все обзоры и советы";
?>