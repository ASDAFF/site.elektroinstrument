<?
$MESS["NEWS_DELETE_CONFIRM"] = "Are you sure you want to delete the news?";
?>