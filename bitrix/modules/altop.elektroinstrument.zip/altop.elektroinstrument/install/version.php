<?$arModuleVersion = array(
	"VERSION" => "2.9.2",
	"VERSION_DATE" => "2015-10-13"
);?>