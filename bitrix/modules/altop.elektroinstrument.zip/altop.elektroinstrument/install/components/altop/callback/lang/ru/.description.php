<?
$MESS ['ALTOP_CALLBACK_COMPONENT_NAME'] = "Заказать обратный звонок";
$MESS ['ALTOP_CALLBACK_COMPONENT_DESCR'] = "Форма для заказа обратного звонка";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>