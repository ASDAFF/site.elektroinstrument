<?
$MESS ['MFP_EMAIL_TO'] = "E-mail, на который будет отправлено письмо";
$MESS ['MFP_REQUIRED_FIELDS'] = "Обязательные поля для заполнения";
$MESS ['MFP_ALL_REQ'] = "(все необязательные)";
$MESS ['MFP_NAME'] = "Имя";
$MESS ['MFP_TEL'] = "Телефон";
$MESS ['MFP_TIME'] = "Время звонка";
$MESS ['MFP_MESSAGE'] = "Сообщение";
?>