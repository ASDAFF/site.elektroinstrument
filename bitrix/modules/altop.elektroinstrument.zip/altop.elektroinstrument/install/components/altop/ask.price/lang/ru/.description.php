<?
$MESS ['ALTOP_CALLBACK_COMPONENT_NAME'] = "Запросить цену";
$MESS ['ALTOP_CALLBACK_COMPONENT_DESCR'] = "Форма для запроса цены";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>