<?
$MESS ['MFT_ORDER_TITLE'] = "Заказать товар";
$MESS ['MFT_ORDER_BUTTON'] = "Заказать";

$MESS ['MFT_ORDER_NAME'] = "Имя";
$MESS ['MFT_ORDER_TEL'] = "Телефон";
$MESS ['MFT_ORDER_TIME'] = "Время звонка";
$MESS ['MFT_ORDER_MESSAGE'] = "Сообщение";
$MESS ['MFT_ORDER_CAPTCHA'] = "Код с картинки";

$MESS ['NAME_NOT_FILLED'] = "Не заполнено поле «Имя»";
$MESS ['TEL_NOT_FILLED'] = "Не заполнено поле «Телефон»";
$MESS ['TIME_NOT_FILLED'] = "Не заполнено поле «Время звонка»";
$MESS ['MESSAGE_NOT_FILLED'] = "Не заполнено поле «Сообщение»";
$MESS ['WRONG_CAPTCHA'] = "Неверно введен «Код с картинки»";

$MESS ['MF_MESSAGE_TITLE'] = "Заказ товара";
$MESS ['MF_MESSAGE_INFO'] = "Информационное сообщение сайта";
$MESS ['MF_MESSAGE_ZAKAZ'] = "Осуществлен заказ товара";
$MESS ['MF_MESSAGE_NAME'] = "Имя:";
$MESS ['MF_MESSAGE_TEL'] = "Телефон:";
$MESS ['MF_MESSAGE_TIME'] = "Время звонка:";
$MESS ['MF_MESSAGE_MESSAGE'] = "Сообщение:";
$MESS ['MF_MESSAGE_GENERAT'] = "Сообщение сгенерировано автоматически.";
$MESS ['MF_OK_MESSAGE'] = "Спасибо, ваше сообщение принято!";
?>