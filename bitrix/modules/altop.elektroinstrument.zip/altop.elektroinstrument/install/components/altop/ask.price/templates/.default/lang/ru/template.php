<?
$MESS ['MFT_ASK_PRICE_TITLE'] = "Запросить цену";
$MESS ['MFT_ASK_PRICE_BUTTON'] = "Запросить";

$MESS ['MFT_ASK_PRICE_NAME'] = "Имя";
$MESS ['MFT_ASK_PRICE_TEL'] = "Телефон";
$MESS ['MFT_ASK_PRICE_TIME'] = "Время звонка";
$MESS ['MFT_ASK_PRICE_MESSAGE'] = "Сообщение";
$MESS ['MFT_ASK_PRICE_CAPTCHA'] = "Код с картинки";

$MESS ['NAME_NOT_FILLED'] = "Не заполнено поле «Имя»";
$MESS ['TEL_NOT_FILLED'] = "Не заполнено поле «Телефон»";
$MESS ['TIME_NOT_FILLED'] = "Не заполнено поле «Время звонка»";
$MESS ['MESSAGE_NOT_FILLED'] = "Не заполнено поле «Сообщение»";
$MESS ['WRONG_CAPTCHA'] = "Неверно введен «Код с картинки»";

$MESS ['MF_MESSAGE_TITLE'] = "Запрос цены";
$MESS ['MF_MESSAGE_INFO'] = "Информационное сообщение сайта";
$MESS ['MF_MESSAGE_ZAKAZ'] = "Осуществлен запрос цены";
$MESS ['MF_MESSAGE_NAME'] = "Имя:";
$MESS ['MF_MESSAGE_TEL'] = "Телефон:";
$MESS ['MF_MESSAGE_TIME'] = "Время звонка:";
$MESS ['MF_MESSAGE_MESSAGE'] = "Сообщение:";
$MESS ['MF_MESSAGE_GENERAT'] = "Сообщение сгенерировано автоматически.";
$MESS ['MF_OK_MESSAGE'] = "Спасибо, ваше сообщение принято!";
?>