<?
$MESS["OBJECT_ID"]                       = "ID объекта комментирования";
$MESS["OBJECT_NAME"]                     = "Название объекта комментирования";
$MESS["IBLOCK_TYPE"]                     = "Тип инфоблока";
$MESS["COMMENTS_IBLOCK_ID"]              = "ID инфоблока, в котором хранятся комментарии";

$MESS["PROPERTY_FIELDS_GROUP_NAME"]      = "Символьные коды свойств";
$MESS["PROPERTY_OBJECT_ID"]              = "ID объекта комментирования";
$MESS["PROPERTY_USER_ID"]                = "ID или имя комментатора";
$MESS["PROPERTY_IP_COMMENTOR"]           = "IP-адрес комментатора";
$MESS["PROPERTY_URL"]                    = "Адрес страницы, где был оставлен комментарий";

$MESS["ACCESS_FIELDS_GROUP_NAME"]        = "Доступ";
$MESS["NON_AUTHORIZED_USER_CAN_COMMENT"] = "Разрешить неавторизованным пользователям добавлять комменарии";
$MESS["PRE_MODERATION"]                  = "Включить премодерацию.";
$MESS["USE_CAPTCHA"]                     = "Показывать капчу для неавторизованных пользователей";
?>