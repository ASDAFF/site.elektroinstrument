<?
$MESS ['ADD_COMMENT_TITLE']		= "Добавить свой отзыв или задать вопрос";
$MESS ['ADD_COMMENT_BUTTON']	= "Отправить";
$MESS ['ADD_COMMENT_ADDED']		= "Отправлено";

$MESS ['NAME']                  = "Имя";
$MESS ['YOUR_COMMENT']          = "Ваш отзыв";
$MESS ['CAPTCHA']               = "Код с картинки";

$MESS ['NAME_NOT_FILLED']       = "Не заполнено поле «Имя»";
$MESS ['COMMENT_NOT_FILLED']    = "Не заполнено поле «Ваш отзыв»";
$MESS ['WRONG_CAPTCHA']         = "Неверно введен «Код с картинки»";
$MESS ['UNKNOWN_ERROR']         = "Неизвестная ошибка.";

$MESS['REVIEW_ON_PRODUCT']		= "Комментарий на товар:";

$MESS['REVIEW_ADD_SUCCESS']		= "Спасибо, Ваш отзыв успешно добавлен!";
$MESS['REVIEW_ADD_AFTER_MODER']	= "Спасибо за Ваш отзыв, он будет опубликован после проверки модератором!";
$MESS['ONLY_AUTH_USER']			= "Только авторизованные пользователи могут оставлять комментарии.<br>Пожалуйста, авторизуйтесь.";
?>