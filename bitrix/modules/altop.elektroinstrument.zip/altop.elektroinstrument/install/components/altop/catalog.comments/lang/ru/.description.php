<?
$MESS ['ALTOP_COMPONENT_NAME'] = "Отзывы к товарам";
$MESS ['ALTOP_COMPONENT_DESCR'] = "Отзывы к товарам";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>