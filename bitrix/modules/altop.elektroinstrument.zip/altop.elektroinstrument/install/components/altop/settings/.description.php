<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("COMPONENT_NAME"),
	"DESCRIPTION" => GetMessage("COMPONENT_DESCR"),
	"ICON" => "/images/icon.gif",
	"PATH" => array(
		"ID" => "altop_tools",
		"NAME" => GetMessage("ALTOP_TOOLS")
	),
);?>