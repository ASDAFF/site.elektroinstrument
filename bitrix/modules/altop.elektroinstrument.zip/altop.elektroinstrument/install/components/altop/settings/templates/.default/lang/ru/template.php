<?
$MESS["THEME_MODIFY"] = "Настройки решения";
$MESS["THEME_RESET"] = "Вернуть по умолчанию";
?>