<?
$MESS ['COMPONENT_NAME'] = "Настройки решения";
$MESS ['COMPONENT_DESCRIPTION'] = "Настройки решения";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>