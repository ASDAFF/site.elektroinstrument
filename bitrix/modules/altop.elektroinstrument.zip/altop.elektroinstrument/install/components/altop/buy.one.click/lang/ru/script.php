<?
$MESS['NAME_NOT_FILLED'] = "Не заполнено поле «Имя»";
$MESS['TEL_NOT_FILLED'] = "Не заполнено поле «Телефон»";
$MESS['EMAIL_NOT_FILLED'] = "Не заполнено поле «Email»";
$MESS['MESSAGE_NOT_FILLED'] = "Не заполнено поле «Сообщение»";
$MESS['WRONG_CAPTCHA'] = "Неверно введен «Код с картинки»";
$MESS['ORDER_COMMENT'] = "Заказ оформлен в 1 клик";
$MESS['SOA_SHT'] = "шт.";
$MESS['ORDER_CREATE_SUCCESS'] = "Заказ успешно оформлен!<br />В ближайшее время наш менеджер свяжется с вами.";
$MESS['ORDER_CREATE_ERROR'] = "Ошибка создания заказа";
?>