<?
$MESS['1CB_GROUP_SKU_PROPERTIES'] = "Настройки товарных предложений";
$MESS['1CB_PARAMETER_IBLOCK_TYPE'] = "Тип информационного блока";
$MESS['1CB_PARAMETER_IBLOCK_ID'] = "ИД информационного блока";
$MESS['1CB_PARAMETER_ELEMENT_ID'] = "ИД товара";
$MESS['1CB_PARAMETER_ELEMENT_PROPS'] = "Свойства товара";
$MESS['1CB_PARAMETER_REQUIRED_ORDER_FIELDS'] = "Обязательные поля формы заказа";
$MESS['1CB_PARAMETER_DEFAULT_PERSON_TYPE'] = "Тип плательщика для вновь зарегистрированного пользователя";
$MESS['1CB_PARAMETER_DEFAULT_ORDER_PROP_NAME'] = "Свойство заказа Ф.И.О. / Контактное лицо";
$MESS['1CB_PARAMETER_DEFAULT_ORDER_PROP_TEL'] = "Свойство заказа Телефон";
$MESS['1CB_PARAMETER_DEFAULT_ORDER_PROP_EMAIL'] = "Свойство заказа E-Mail";
$MESS['1CB_PARAMETER_DEFAULT_DELIVERY'] = "Cпособ доставки";
$MESS['1CB_PARAMETER_DEFAULT_PAYMENT'] = "Cпособ оплаты";
$MESS['1CB_BUY_MODE_ONE'] = "Оформлять только выбранный товар";
$MESS['1CB_BUY_MODE_ALL'] = "Оформлять все товары в корзине";
$MESS['1CB_PARAMETER_BUY_MODE'] = "Режим покупки";
$MESS['1CB_PARAMETER_DUPLICATE_LETTER_TO_EMAILS'] = "Дублировать письмо о заказе на следующие адреса";
$MESS['1CB_DUB_DEFAULT_EMAIL'] = "E-Mail адрес по умолчанию: ";
$MESS['1CB_DUB_ADMIN_EMAIL'] = "E-Mail администратора сайта: ";
$MESS['1CB_DUB_SALES_EMAIL'] = "E-Mail отдела продаж: ";
$MESS['1CB_DUB_DUB_EMAIL'] = "E-mail(ы), на который дублируются все исходящие сообщения: ";
$MESS['1CB_FIELD_OPTION_NAME'] = "Имя";
$MESS['1CB_FIELD_OPTION_TEL'] = "Телефон";
$MESS['1CB_FIELD_OPTION_EMAIL'] = "Email";
$MESS['1CB_FIELD_OPTION_MESSAGE'] = "Сообщение";
$MESS['1CB_NOT_SET'] = "Не указывать";
?>