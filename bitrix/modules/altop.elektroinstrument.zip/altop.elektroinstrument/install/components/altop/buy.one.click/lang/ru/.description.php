<?
$MESS ['ALTOP_COMPONENT_NAME'] = "Купить в 1 клик";
$MESS ['ALTOP_COMPONENT_DESCR'] = "Форма для покупки в 1 клик";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>