<?
$MESS['MFT_BOC_TITLE'] = "Купить в 1 клик";
$MESS['MFT_BOC_BUTTON'] = "Купить";
$MESS['MFT_NAME'] = "Имя";
$MESS['MFT_TEL'] = "Телефон";
$MESS['MFT_EMAIL'] = "Email";
$MESS['MFT_MESSAGE'] = "Сообщение";
$MESS['MFT_CAPTCHA'] = "Код с картинки";
?>