<?if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters = array(
	"IBLOCK_TYPE" => array(
		"HIDDEN" => "Y"
	),
	"IBLOCK_ID" => array(
		"HIDDEN" => "Y"
	),
	"ELEMENT_ID" => array(
		"HIDDEN" => "Y"
	),
	"ELEMENT_PROPS" => array(
		"HIDDEN" => "Y"
	),
	"BUY_MODE" => array(
		"HIDDEN" => "Y"
	)
);?>