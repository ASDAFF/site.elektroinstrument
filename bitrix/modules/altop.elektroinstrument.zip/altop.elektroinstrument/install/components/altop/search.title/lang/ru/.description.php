<?
$MESS["ALTOP_BST_NAME"] = "Удобный AJAX поиск по каталогу";
$MESS["ALTOP_BST_DESCRIPTION"] = "Удобный AJAX поиск по каталогу";
$MESS["ALTOP_TOOLS"] = "ALTOP TOOLS";
?>