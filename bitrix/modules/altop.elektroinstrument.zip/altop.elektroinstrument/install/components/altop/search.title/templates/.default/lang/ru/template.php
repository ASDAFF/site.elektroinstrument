<?
$MESS["ALTOP_CATALOG_SEARCH"] = "Поиск по товарам, брендам, категориям";
$MESS["ALTOP_SEARCH_BUTTON"] = "Найти";
?>