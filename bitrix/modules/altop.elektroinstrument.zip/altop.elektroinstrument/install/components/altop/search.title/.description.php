<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ALTOP_BST_NAME"),
	"DESCRIPTION" => GetMessage("ALTOP_BST_DESCRIPTION"),
	"ICON" => "/images/search_title.gif",
	"CACHE_PATH" => "Y",
	"PATH" => array(
		"ID" => "altop_tools",
		"NAME" => GetMessage("ALTOP_TOOLS")
	),
);
?>