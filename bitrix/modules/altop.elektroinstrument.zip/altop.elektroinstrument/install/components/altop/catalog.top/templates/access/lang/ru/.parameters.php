<?
$MESS['T_IBLOCK_DESC_IMG_WIDTH'] = "Ширина картинки для анонса";
$MESS['T_IBLOCK_DESC_IMG_HEIGHT'] = "Высота картинки для анонса";
$MESS["T_IBLOCK_DESC_SHARPEN"] = "Резкость при масштабировании картинок (от 1 до 100)";
?>