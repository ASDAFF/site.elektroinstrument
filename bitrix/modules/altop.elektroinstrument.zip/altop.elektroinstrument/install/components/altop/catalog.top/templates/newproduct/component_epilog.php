<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$APPLICATION->AddHeadScript('/bitrix/components/altop/ask.price/templates/.default/script.js');
$APPLICATION->SetAdditionalCSS('/bitrix/components/altop/ask.price/templates/.default/style.css');

$APPLICATION->AddHeadScript('/bitrix/components/altop/ask.price/templates/order/script.js');
$APPLICATION->SetAdditionalCSS('/bitrix/components/altop/ask.price/templates/order/style.css');
?>