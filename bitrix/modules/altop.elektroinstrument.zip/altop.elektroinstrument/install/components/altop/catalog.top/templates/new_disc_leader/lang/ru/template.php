<?
$MESS["COUNT_ITEMS"] = "Товаров:";
$MESS["SECT_SORT_LABEL_FULL"] = "Сортировать по";
$MESS["SECT_SORT_LABEL_SHORT"] = "По";
$MESS["SECT_SORT_default"] = "умолчанию";
$MESS["SECT_SORT_price"] = "цене";
$MESS["SECT_SORT_rating"] = "рейтингу";
$MESS["SECT_COUNT_LABEL_FULL"] = "Показывать по";
$MESS["SECT_COUNT_LABEL_SHORT"] = "По";
$MESS["SECT_COUNT_ALL"] = "Все";
$MESS["SECT_VIEW_list"] = "Список";
$MESS["SECT_VIEW_table"] = "Плитка";
$MESS["SECT_VIEW_price"] = "Прайс";
$MESS["PAGER_TITLE_NEWPRODUCT"] = "Новинки";
$MESS["PAGER_TITLE_SALELEADER"] = "Хиты продаж";
$MESS["PAGER_TITLE_DISCOUNT"] = "Скидки";
$MESS["SECT_TITLE"] = "Страница";
?>