<?
$MESS ['IBLOCK_MAIN_PAGE_TEMPLATE_NAME'] = "Top элементов каталога";
$MESS ['IBLOCK_MAIN_PAGE_TEMPLATE_DESCRIPTION'] = "Выводит в таблице TOP элементов из всех разделов в соответствии с заданной сортировкой (используется как правило на главной странице сайта)";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>