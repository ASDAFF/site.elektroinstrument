<?
$MESS["IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль Информационных блоков не установлен";
$MESS["CATALOG_ERROR2BASKET"] = "Ошибка добавления товара в корзину";
$MESS["CATALOG_PRODUCT_NOT_FOUND"] = "Товар не найден";
?>