<?
$MESS["USER_EXIT"] = "Выход";
?>