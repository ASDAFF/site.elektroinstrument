<?
$MESS ['ALTOP_USER_COMPONENT_NAME'] = "Информация о текущем пользователе";
$MESS ['ALTOP_USER_COMPONENT_DESCR'] = "Информация о текущем пользователе";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>