<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ALTOP_USER_COMPONENT_NAME"),
	"DESCRIPTION" => GetMessage("ALTOP_USER_COMPONENT_DESCR"),
	"ICON" => "/images/icon.gif",
	"PATH" => array(
		"ID" => "altop_tools",
		"NAME" => GetMessage("ALTOP_TOOLS")
	),
);
?>