<?
$MESS ["MY_DELAY"] = "Отложенные";
?>