<?
$MESS ['ALTOP_DEFAULT_TEMPLATE_NAME'] = "Отложенные товары";
$MESS ['ALTOP_DEFAULT_TEMPLATE_DESCRIPTION'] = "Отображает количество отложенных товаров";
$MESS ['ALTOP_TOOLS'] = "ALTOP TOOLS";
?>