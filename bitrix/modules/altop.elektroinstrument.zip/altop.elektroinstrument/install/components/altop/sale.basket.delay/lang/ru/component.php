<?
$MESS['SALE_MODULE_NOT_INSTALL']="Модуль Интернет-магазин не установлен.";
$MESS['TSB1_BASKET_TEXT'] = "В вашей корзине <b>#NUM#</b> товар#END#";
$MESS['TSB1_WORD_OBNOVL_END1'] = "ов";
$MESS['TSB1_WORD_OBNOVL_END2'] = "ов";
$MESS['TSB1_WORD_OBNOVL_END3'] = "";
$MESS['TSB1_WORD_OBNOVL_END4'] = "а";
$MESS['TSB1_EMPTY'] = "Ваша корзина пуста";
?>