<?
$MESS["MAIN_OPTIONS"] = "Основные";
$MESS["SHOW_SETTINGS_PANEL"] = "Отображать панель настроек";
$MESS["CATALOG_LOCATION"] = "Расположение каталога";
$MESS["CATALOG_LOCATION_LEFT"] = "Слева";
$MESS["CATALOG_LOCATION_HEADER"] = "В шапке";
$MESS["CATALOG_VIEW"] = "Вид каталога";
$MESS["CATALOG_VIEW_TWO_LEVELS"] = "2 уровня";
$MESS["CATALOG_VIEW_FOUR_LEVELS"] = "4 уровня";
$MESS["SMART_FILTER_LOCATION"] = "Расположение умного фильтра";
$MESS["SMART_FILTER_LOCATION_VERTICAL"] = "Слева";
$MESS["SMART_FILTER_LOCATION_HORIZONTAL"] = "Над товарами";
$MESS["CART_LOCATION"] = "Расположение панели с корзиной";
$MESS["CART_LOCATION_BOTTOM"] = "Снизу";
$MESS["CART_LOCATION_TOP"] = "Сверху";
$MESS["CART_LOCATION_RIGHT"] = "Справа";
$MESS["CART_LOCATION_LEFT"] = "Слева";
$MESS["PRODUCT_TABLE_VIEW"] = "Плитка товара";
$MESS["PRODUCT_TABLE_VIEW_ARTNUMBER"] = "Артикул";
$MESS["PRODUCT_TABLE_VIEW_RATING"] = "Рейтинг";
$MESS["PRODUCT_TABLE_VIEW_PREVIEW_TEXT"] = "Краткое описание";
$MESS["PRODUCT_TABLE_VIEW_OLD_PRICE"] = "Старая цена";
$MESS["PRODUCT_TABLE_VIEW_PERCENT_PRICE"] = "Экономия";
$MESS["GENERAL_SETTINGS"] = "Общие настройки";
$MESS["GENERAL_SETTINGS_PRODUCT_QUANTITY"] = "Количество товара";
?>