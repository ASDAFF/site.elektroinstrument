<?
$MESS["TAB_OPTIONS"] = "Настройки";
$MESS["TAB_OPTIONS_TITLE"] = "Общие настройки";
$MESS["MAIN_ADMIN_SET_CONTROLLER_ALT"] = "Данное значение переопределяется Контроллером";
$MESS["MAIN_OPT_APPLY"] = "Применить";
$MESS["MAIN_OPT_APPLY_TITLE"] = "Сохранить изменения и остаться в форме";
$MESS["MAIN_OPT_CANCEL"] = "Отменить";
$MESS["MAIN_OPT_CANCEL_TITLE"] = "Не сохранять изменения и вернуться";
$MESS["WILL_CLEAR_HTML_CACHE_NOTE"] = "После изменения настроек будет выполнена очистка композитного (html) кеша";
$MESS["NO_RIGHTS_FOR_VIEWING"] = "Недостаточно прав для просмотра";
?>